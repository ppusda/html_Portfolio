
public class Salaryman {
	
	public int money = 1000000;
	public Salaryman() {
		
	}
	public Salaryman(int money) {
		this.money = money;
	}
	int getannualGross() {
	
		return money*12 + money*5;
	}
	public static void main(String[] args) {
		System.out.println(new Salaryman().getannualGross());
		System.out.println(new Salaryman(2_000_000).getannualGross());
		
	}
}

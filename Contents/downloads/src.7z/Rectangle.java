
public class Rectangle {

	public double height;
	public double width;
	
	public Rectangle(double height, double width) {
		this.height = height;
		this.width = width;
	}	
	
	double getArea() {
		return height * width;
	}
	
	double getCircumfence() {	
		return height*2 + width*2;
	}
	
	public static void main(String[] args) {
		Rectangle rc = new Rectangle(3.82, 8.65);
		System.out.println("���� : " + rc.getArea());
		System.out.println("�ѷ� : " + rc.getCircumfence());
		
	}


}

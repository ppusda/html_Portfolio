public class Computer {
	public static final String[] osType = {"������ 7", "���� OS X", "�ȵ���̵�"};
	int OS;
	int mainMemory = 8;
	public Computer(int OS, int mainMemory) {
		this.OS = OS;
		this.mainMemory = mainMemory;
	}
	
	public void print() {
		System.out.printf("� ü�� : %s, ���θ޸� : %d %n", osType[OS], mainMemory);
	}
	public static void main(String[] args) {
		Computer pc = new Computer(0, 16);
		Computer apple = new Computer(1, 32);
		Computer galaxy = new Computer(2, 16);
		pc.print();
		apple.print();
		galaxy.print();
	}
}
